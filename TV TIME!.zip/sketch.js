// It's a TV! Press the green ON button to turn it on and the red OFF button to turn it off. 
// While holding your mouse over the dial select 'A' or 'D' to change the channel.
// Theres something new on the tv everytime you run the program.


let SCREENCOLOR;
 let RED; 
  let GREEN;
  let BLUE; 
let TVON = false


function setup() {
  createCanvas(400, 400);

colorMode(RGB, 255);

  background(200);

  RED = random(0,255);
  GREEN = random(0,255);
  BLUE = random(0,255);

  

}
 function draw() {
   
   if (TVON === false) { SCREENCOLOR = color(55)}
   else {SCREENCOLOR = color(RED,BLUE,GREEN)

   textFont ('Isometra')
   textSize(50)
   fill(237,228,125)
text ('Its TV Time!', 70,300) 

        }
   
  // TV box
   fill (204,191,237)
rect (100,100,200,150);

  // TV Antennae
  line (180,100,140,70);
  line (220,100,260,70);

   
   // TV Screen
     fill (SCREENCOLOR);
   rect (120,120, 140, 110)


   // Channel Dial
     fill (223,237,232);
  circle (280,130,25);

   // ON button
fill (65,153,99);
circle (280, 190, 15);


   // OFF button
fill (237,73,63);
circle (280, 210, 15);

 }   
// end of draw

function mouseClicked () {
if (dist(mouseX, mouseY, 280,210)<15) {

TVON = false
}
  if (dist(mouseX, mouseY, 280,190)<15) {

TVON = true
  
} 
}
// end of keypress
   
   function keyPressed () {
if (key==='a') {
if (TVON===true) {
if (dist(mouseX, mouseY, 280,130)<25) {

RED = max(0, RED-random(1,5));
BLUE = max(235, BLUE+random(1,5));
GREEN = max (0, GREEN-random(1,5));
  
}
}

  
}
     if (key==='d'){
if (TVON===true){
if (dist(mouseX,mouseY,280,130)<25) {

RED = max(235, RED+random(1,5));
BLUE = max(0, BLUE-random(1,5));
GREEN = max (235, GREEN+random(1,5));

  
}
}
}
   }
// end of keypress

