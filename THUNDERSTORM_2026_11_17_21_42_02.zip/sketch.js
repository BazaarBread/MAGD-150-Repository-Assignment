let even = true;
let lightningTilt
let lightningSize

function setup() {
  createCanvas(400, 400);

  frameRate(5);

  colorMode(RGB,255);

angleMode (DEGREES);
  
}

// END OF SETUP FUNCTION

function draw() {

  background(220);

  strokeWeight(1);

 if (frameCount % 2 === 0) {
    even = true;
  } else {
    even = false;
  }
  
for (let r = 10; r < 400; r += 15) {
  
if (even===true) {
  
 {
    line(r, 25, r, 45);
     line(r, 100, r, 120);
  line(r, 175, r, 195);
   line(r, 250, r, 270);
   line(r, 325, r, 345);
  }
}

if (even === false) {
  
line(r, 65, r, 85);
     line(r, 140, r, 160);
  line(r, 215, r, 235);
   line(r, 290, r, 310);
   line(r, 365, r, 385);
}
}

  strokeWeight(0);
  
fill (60,60,60);
  
  circle(200,30,100);
  circle(400,30,100);
    circle(0,30,100);
    circle(100,30,150);
  circle(300,30,150);
}

// END OF DRAW FUNCTION

function keyPressed () {

lightningStrike (random(0,400),5);
  
}

function lightningStrike (x,y) {

push ();

translate(x,y);

  lightningSize=(random(0.2,2));
  lightningTilt=(random(-30,30));;

  fill (255,255,0);

  rotate (lightningTilt);
  scale (lightningSize);

print("Angle");
print(lightningTilt);
print("Size");
print(lightningSize);
 
  // BEGIN LIGHTNING
beginShape ();
  
vertex (55,100);
vertex (5,100);
vertex (30, 5);
vertex (80,5);
vertex (62,70);
vertex (112,70);
vertex (35,200);
vertex (55,100);
  
endShape ();
// END LIGHTNING

pop ();

}
// END FUNCTION lightningStrike
