let player;
let wins; 
let objective; 
let playx;
let playy;
let enemies;
let lose; 
let safety; 

function setup() {
  createCanvas(400, 400);

  world.gravity.y = 0;

  lose = false;
  
  player = new Sprite(200, 25, 25, 25);

  player.color = 'white';
  player.autoDraw = false;

safety = new Sprite (150,0, 150,100);

safety.color = 'blue';
safety.autoDraw = false;
safety.collider = 'none'; 

 objective = new Sprite (200,390,410,25);

 objective.color = 'green';
  objective.autoDraw = false;

  wins = 0

  enemies = new Group();
enemies.color = 'purple';
enemies.collider = 'dynamic';

  enemies.overlaps(objective);
  enemies.collides(objective, false);

}

function spawnEnemy() {
  new enemies.Sprite (random(50, 350),random(50, 350), random(10,60), random (10,60));

  
}
function draw() {

player.x = constrain(player.x, player.w / 2, width - player.w / 2);
player.y = constrain(player.y, player.h / 2, height - player.h / 2);
  
  // WASD movement
  player.velocity.x = 0;
  player.velocity.y = 0;

  if (lose === false) {

  if (kb.pressing('a')) {
    player.velocity.x = -4;
  }

  if (kb.pressing('d')) {
    player.velocity.x = 4;
  }

  if (kb.pressing('w')) {
    player.velocity.y = -4;
  }

  if (kb.pressing('s')) {
    player.velocity.y = 4;
  }
  }

background (50);

fill ('grey');
textSize (20);
text ("Score: " + wins, 50,50)
  
 objective.draw();

  player.draw();

  for (let enemy of enemies) {
  enemy.draw();
}

  if (player.overlaps(objective)) {
    
    wins = wins + 1

  player.x = 200;
player.y = 25;

  spawnEnemy();
    
  }

if (enemies.collides(safety)) {

enemy.remove ();
}

if (lose === true) {

  textSize (35);
fill ('red');
text ("LOSE", 150,200);
  
}
  
  if (player.collides(enemies)) {

 player.x = 200;
player.y = 25; 

lose = true;

player.remove ();

    
  }
  
}
